import torch
from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import os
import time
import uvicorn
from configparser import ConfigParser
import logging 
import pandas as pd
import json
from typing import Dict
from fastapi import FastAPI
import json
from datetime import datetime
from bart_model_training import training
from bart_model_training import convo_data_preprocessing
from datetime import datetime
import re

logging.config.fileConfig('logger_config.ini', disable_existing_loggers=False)
logger = logging.getLogger(__name__)
app = FastAPI()

ENVIRON = 'dev'
config = ConfigParser()
config.read('config.ini')

logger.info(f'Runnning in {ENVIRON} environment')

API_MODEL_PATH = config.get(ENVIRON, 'api_model_path')
API_TOKENIZER_PATH = config.get(ENVIRON, 'api_tokenizer_path')
FAQ_MODEL_PATH = config.get(ENVIRON, 'faq_model_path')
FAQ_TOKENIZER_PATH = config.get(ENVIRON, 'faq_tokenizer_path')

FAQ_INTENTS = config.get(ENVIRON, 'faq_intents')

CONVO_MODEL_PATH = config.get(ENVIRON, 'convo_model_path')
CONVO_TOKENIZER_PATH = config.get(ENVIRON, 'convo_tokenizer_path')
# Set device to use GPU if available,+ otherwise use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logger.info(f'model started loading on {device} device')
logger.info(f'model load completed')


class IntentInput(BaseModel):
    text: str
    message_id: str

class FaqInput(BaseModel):
    text: str
    intent: str
    message_id: str

class ApiInput(BaseModel):
    text: str
    intent: str
    message_id: str

class ChatInput(BaseModel):
    user_id: str
    input_text: str
     
train_details_file = "train_details.json"

if os.path.isfile(train_details_file):
    with open(train_details_file, "r") as f:
        training_details_json = json.load(f)
else:
    training_details_json = {}


@app.post("/faq_training")
def faq_training(file: UploadFile = File(...)):
    training_type = 'FAQ_training'

    # Check if there is an existing conversation for this user
    if training_type not in training_details_json:
        training_details_json[training_type] = []

    training_details = training_details_json[training_type]
    if len(training_details)==0:
        details = {
              "training_id": 1,
              'timestamp': datetime.utcnow().isoformat()
              }
        training_details.append(details)
        print(training_details)
    else:
        old_details = training_details[-1]
        training_id = old_details['training_id'] + 1
        details = {
            "training_id": training_id,
            'timestamp': datetime.utcnow().isoformat()
        }
    try:
        contents = file.file.read()
        with open(file.filename, "wb") as f:
            f.write(contents)
        return "Success"
    except Exception as e:
        logger.exception(e)
        return {"message": "There was an error uploading the file"}
    finally:
        file.file.close()
        filepath = "./%s" % (file.filename)
        try:
            df_train = pd.read_csv(filepath,encoding = 'unicode_escape' )
            df_train = df_train.dropna()
            total_training_data = len(df_train)
            df_train['user_input'] = df_train['user_input'].apply(lambda text: re.sub('[^A-Za-z0-9\s]+', '', text))
            bart_model, bart_tokenizer, total_loss = training(df_train)
            bart_model.save_pretrained(FAQ_MODEL_PATH)
            bart_tokenizer.save_pretrained(FAQ_TOKENIZER_PATH)
            training_details.append(details)
            details['total_training_data'] = total_training_data
            details['loss'] = total_loss
        
        except Exception as e:
            logger.exception(e) 

        with open(train_details_file, "w") as f:
            json.dump(training_details_json, f)

        # Return the bot's response to the user
        return {'summary': details}

@app.post("/convo_training")
def convo_training(file: UploadFile = File(...)):

    training_type = 'convo_training'
    # Check if there is an existing conversation for this user
    if training_type not in training_details_json:
        training_details_json[training_type] = []

    training_details = training_details_json[training_type]

    if len(training_details)==0:
        details = {
              "training_id": 1,
              'timestamp': datetime.utcnow().isoformat()
              }
        training_details.append(details)
        print(training_details)
    else:
        old_details = training_details[-1]
        training_id = old_details['training_id'] + 1
        details = {
            "training_id": training_id,
            'timestamp': datetime.utcnow().isoformat()
        }

    try:
        contents = file.file.read()
        with open(file.filename, "wb") as f:
            f.write(contents)
        return "Success"
    except Exception as e:
        logger.exception(e)
        return {"message": "There was an error uploading the file"}
    finally:
        file.file.close()
        filepath = "./%s" % (file.filename)
        try:
            df = pd.read_csv(filepath, encoding = 'unicode_escape')
            df = df.fillna('khali')
            print(df.head())
            df['user_intent'] = df['user_intent'].apply(lambda x:x.lower())
            convo_count = df['user_intent'].value_counts()
            convo_count_dict = convo_count.to_dict()
            convo_count_dict.pop('khali', None)
            convo_count_dict.pop('subintent', None)
            details['convo_details'] = convo_count_dict
            total = 0
            for item in convo_count_dict.values():
                total = total + item
            details['total_convo_count'] = total
            training_details.append(details)
            convo_data = convo_data_preprocessing(df)
            bart_model, bart_tokenizer, total_loss = training(convo_data)
            details['total_loss'] = total_loss
            bart_model.save_pretrained(CONVO_MODEL_PATH )
            bart_tokenizer.save_pretrained(CONVO_TOKENIZER_PATH)
        except Exception as e:
            logger.exception(e) 

        with open(train_details_file, "w") as f:
            json.dump(training_details_json, f)

        # Return the bot's response to the user
        return {'summary': details}


