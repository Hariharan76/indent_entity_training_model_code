from transformers import BartTokenizer, BartForConditionalGeneration
import logging
import random
logging.config.fileConfig('logger_config.ini')
logger = logging.getLogger()

class FAQResponseModel:
    def __init__(self, model_path, tokenizer_path, device):
        try:
            self.device = device
            self.response = {}
            self.model_faq = BartForConditionalGeneration.from_pretrained(model_path, return_dict=True).to(self.device)
            self.tokenizer_faq = BartTokenizer.from_pretrained(tokenizer_path)
        except Exception as e:
            logger.error(e, stack_info=True, exc_info=True)

    def preprocessing(self):
        pass

    def predict(self, input_text):
        logger.info('inside FAQ response model !')
        logger.info(f'input text : {input_text}')
        # if input.intent=='greetings':
        #     upper_index = random.randint(0,len(input_text))
        #     input_text_processed = input_text[:upper_index] + input_text[upper_index:].upper()
        answer = ''
        try:
            input_ids = self.tokenizer_faq.encode(input_text, return_tensors='pt').to(self.device)
            output_ids = self.model_faq.generate(input_ids=input_ids,
                                        num_beams=4,
                                        length_penalty=2.0,
                                        max_length=512,
                                        no_repeat_ngram_size=3,
                                        early_stopping=True)[0]
            answer = self.tokenizer_faq.decode(output_ids, skip_special_tokens=True)
        except Exception as e:
            logger.error(e, stack_info=True, exc_info=True)
            answer = ''
        finally:
            self.response['response']=answer
        return self.response