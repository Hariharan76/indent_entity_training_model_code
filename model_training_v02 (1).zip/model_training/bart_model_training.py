import torch
from torch.utils.data import DataLoader, TensorDataset
from transformers import BartForConditionalGeneration, BartTokenizer
import pandas as pd
from IPython.display import HTML, display
from configparser import ConfigParser
import re
from nltk.stem import SnowballStemmer
from nltk.stem import WordNetLemmatizer
import nltk
nltk.download('wordnet')


# Set device to use GPU if available, otherwise use CPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the BART model and tokenizer
model = BartForConditionalGeneration.from_pretrained('facebook/bart-large').to(device)
tokenizer = BartTokenizer.from_pretrained('facebook/bart-large')

ENVIRON = 'dev'
config = ConfigParser()
config.read('config.ini')

BATCH_SIZE = config.get(ENVIRON, 'batch_size')
LEARNING_RATE = config.get(ENVIRON, 'learning_rate')
NUM_EPOCHS = config.get(ENVIRON, 'num_epochs')


def progress(loss,value, max=5):
    return HTML(""" Batch loss :{loss}
        <progress
            value='{value}'
            max='{max}',
            style='width: 100%'
        >
            {value}
        </progress>
    """.format(loss=loss,value=value, max=max))

def preprocess_text(text):
    remove_punct=False
    if text is None or pd.isnull(text):
        return ''
    # Remove special characters using regular expression
    if remove_punct:
        text = re.sub('[^A-Za-z0-9\s]+', '', text)
    
    # Tokenize text
    tokens = text.lower().split()

    lemmatizer = WordNetLemmatizer()
    lemma_tokens = [lemmatizer.lemmatize(word) for word in tokens]

    # Initialize SnowballStemmer for stemming
    # stemmer = SnowballStemmer('english')
    
    # # Stem the tokens
    # stemmed_tokens = [stemmer.stem(token) for token in tokens]

    # Join the stemmed tokens into a single string
    preprocessed_text = ' '.join(lemma_tokens)
    
    return preprocessed_text

def convo_data_preprocessing(df):
    ques_list = []
    ans_list = []
    val = []
    df['user_query'] = df['user_query'].apply(preprocess_text)
    df['bot_query'] = df['bot_query'].apply(preprocess_text)
    for ques, ans in zip(df['user_query'], df['bot_query']):
        if ques=='khali':
            del val
            val = []
        else:
            val.append('user : '+str(ques))
            ques_list.append(val[:])
            ans_list.append('bot : '+str(ans))
            val.append('bot : '+str(ans))
    train_data_df = pd.DataFrame()
    train_data_df['user_input_convo'] = ques_list
    train_data_df['bot_output'] = ans_list
    train_data_df['user_input'] = train_data_df['user_input_convo'].apply(lambda x:' '.join(x))
    return train_data_df

def training(df):
    df['user_input'] = df['user_input'].apply(lambda x:x.lower())
    df['bot_output'] = df['bot_output'].apply(lambda x:x.lower())
    input_text = list(df['user_input'])
    target_text = list(df['bot_output'])
    print(input_text[0:5])
    print(target_text[0:5])
    # Tokenize the input and target texts
    inputs = tokenizer(input_text, padding=True, truncation=True, max_length=200, return_tensors='pt').to(device)
    targets = tokenizer(target_text, padding=True, truncation=True, max_length=1230, return_tensors='pt').to(device)

    # Define the training data
    train_dataset = TensorDataset(inputs['input_ids'], inputs['attention_mask'], targets['input_ids'], targets['attention_mask'])

    # Define the training parameters
    batch_size = int(BATCH_SIZE)
    learning_rate = float(LEARNING_RATE)
    num_epochs = int(NUM_EPOCHS)

    num_of_batches=len(df)/batch_size
    num_of_batches=int(num_of_batches)

    # Define the optimizer and loss function
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    loss_fn = torch.nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)

    #for display
    loss_per_10_step = []

    # Train the model
    for epoch in range(num_epochs):
        print('Running epoch: {}'.format(epoch))
        total_loss = 0
        # out = display(progress(1, num_of_batches+1), display_id=True)

        # Iterate over the training data 
        i=0
        for batch in DataLoader(train_dataset, batch_size=batch_size, shuffle=True):
            input_ids, input_mask, target_ids, target_mask = tuple(t.to(device) for t in batch)
            i = i+1

            # Compute the model outputs and loss
            outputs = model(input_ids=input_ids, attention_mask=input_mask, decoder_input_ids=target_ids[:, :-1], decoder_attention_mask=target_mask[:, :-1])[0]
            loss = loss_fn(outputs.view(-1, outputs.size(-1)), target_ids[:, 1:].reshape(-1))
            
            #for display
            loss_num = loss.item()
            total_loss+=loss_num
            if i%10==0:
                loss_per_10_step.append(loss_num)
            # out.update(progress(loss_num, i, num_of_batches+1 ))
            # Backpropagate and update the model parameters
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        # Print the average loss for the epoch
        print("Epoch:", epoch + 1, "Average Loss:", total_loss / len(train_dataset))
    
    return model, tokenizer, total_loss / len(train_dataset)
# filepath = 'D:\workspace\BART\Faq_variations_new_03_28_2023_v02.csv'
# filepath = 'D:\workspace\BART\Copy of Worktual_data final.xlsx'
# df_train = pd.read_csv('D:\workspace\BART\Copy_of_Worktual_data_final.csv',encoding= 'unicode_escape')
# df_train = df_train.dropna()
# bart_model, bart_tokenizer = training(df_train)
# bart_model.save_pretrained("FAQ_MODEL_PATH_GOPI")
# bart_tokenizer.save_pretrained("FAQ_TOKENIZER_PATH_GOPI")

    # model.save_pretrained("D:\workspace\BART\model_bart")
    # tokenizer.save_pretrained("D:\workspace\BART\model_bart_answer_prediction_03_30_2023")